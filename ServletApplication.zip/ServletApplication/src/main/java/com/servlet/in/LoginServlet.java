package com.servlet.in;

import java.io.IOException;

import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServlet;

public class LoginServlet extends HttpServlet {
	
 private static final  String AdminUserName ="admin";
 private static final  String AdminPassWord ="password";
 
 @Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	} 
 
}

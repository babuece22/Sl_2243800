package com.lao.abstraction;

public class Bmw extends Cars {

	
	@Override
	public void engineSecret() {
		System.out.println("Bmw engin secret");
	}
	
	@Override
	public void CompanyVault() {
		System.out.println("Bmw Companyvault");
	}
	public static void main(String[] args) {
		
		Cars car = new Bmw();
		car.CompanyVault();
		car.engineSecret();
		
	}
}

package com.lao.abstraction;

public  class Cars {

	public void engineSecret() {
		
		System.out.println("Car eginSecret");
	}
	
	public void CompanyVault() {
		System.out.println("Car companyvault");
	}
}

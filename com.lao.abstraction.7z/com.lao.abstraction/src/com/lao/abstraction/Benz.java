package com.lao.abstraction;

public class Benz extends Cars{

	@Override
	public void CompanyVault() {
		System.out.println("Benz companyvault");
	}
	
	@Override
	public void engineSecret() {
		System.out.println("Benz engineSecret");
	}
	
	public static void main(String[] args) {
		
		Cars car = new Benz();
		car.CompanyVault();
		car.engineSecret();
	}
}

package com.lao.abstraction;

public interface Interface2 extends UpComingProject {

}

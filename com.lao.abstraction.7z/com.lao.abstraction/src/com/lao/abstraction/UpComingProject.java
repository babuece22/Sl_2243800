package com.lao.abstraction;

public interface UpComingProject {
    String project="New music";
    
    void  employee();
}
	
    
